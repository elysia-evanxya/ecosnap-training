// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "TrainEcoSnap",
    platforms: [.macOS(.v13)],
    targets: [
        .executableTarget(
            name: "TrainEcoSnap",
            path: "Sources/TrainEcoSnap"
        )
    ]
)
